/*
document.addEventListener("DOMContentLoaded", function () {
    const testDiv = document.getElementById("test-div");
    console.log(testDiv)
})

document.addEventListener("DOMContentLoaded", () => {
    const testDiv = document.getElementById("test-div");
    console.log(testDiv)
})

function loadDiv() {
    const testDiv = document.getElementById("test-div");
    console.log(testDiv)
}

document.addEventListener("DOMContentLoaded", loadDiv)

const loadDiv2 = () => {
    const testDiv = document.getElementById("test-div");
    console.log(testDiv)
}
document.addEventListener("DOMContentLoaded", loadDiv2)

const loadDiv3 = function () {
    const testDiv = document.getElementById("test-div");
    console.log(testDiv)
}
document.addEventListener("DOMContentLoaded", loadDiv3)
 */

// Funkce pro animaci textu - zvětšování a zmenšování velikosti písma
const animateText = (element) => {
    // Získání původní velikosti písma prvku
    let originalFontSize = parseFloat(window.getComputedStyle(element).getPropertyValue('font-size'));
    let currentFontSize = originalFontSize; // Aktuální velikost písma
    let isIncreasing = true; // Směr změny velikosti - true = zvětšování, false = zmenšování
    const maxFontSize = 50; // Maximální povolená velikost písma

    setInterval(() => {
        // Zvětšení nebo zmenšení písma na základě aktuálního směru
        currentFontSize += isIncreasing ? 1 : -1;

        // Změna směru, pokud je dosaženo limitů
        if (currentFontSize >= maxFontSize || currentFontSize <= originalFontSize) {
            isIncreasing = !isIncreasing;
        }

        // Aktualizace velikosti písma
        element.style.fontSize = `${currentFontSize}px`;
    }, 100); // Animace probíhá každých 100 ms
};

// Funkce pro úpravu vlastností prvku a zahájení animace textu
const modifyDiv = () => {
    const testDiv = document.getElementById("test-div"); // Získání prvku s ID "test-div"
    testDiv.textContent = "Nazdárek"; // Nastavení textového obsahu
    testDiv.style.color = "#00f4ff"; // Změna barvy textu
    testDiv.style.fontSize = "20px"; // Nastavení základní velikosti písma

    animateText(testDiv); // Zahájení animace textu
};

document.addEventListener("DOMContentLoaded", modifyDiv);
// alternativní zápis event listeneru
/*document.addEventListener("DOMContentLoaded", () => {
    modifyDiv()
});*/

//Používá se zejména k modifikaci obsahu bez nutnosti komunikace se serverem (technologie AJAX) a pro různé visuální efekty jako jsou plynulé animace a podobně, které ale postupně nahrazuje CSS.
//Zdroj: https://jecas.cz/js
//V dnešní době digitálního designu a web developmentu se animace staly nezbytnou součástí vytváření atraktivních a interaktivních webových stránek. Použití animací může zlepšit uživatelskou zkušenost tím, že přitahuje pozornost k důležitým prvkům, oživuje rozhraní a činí interakce s webovou stránkou zábavnějšími. V tomto článku se zaměříme na základy tvorby vlastních animací pomocí CSS a JavaScriptu, dvou základních nástrojů moderního webdesignu.
//Zdroj: https://www.mydreams.cz/cz/wiki/8781-vytvareni-vlastnich-animaci-pomoci-css-a-javascriptu.html